#!/bin/bash

echo "This is rpm msg."
